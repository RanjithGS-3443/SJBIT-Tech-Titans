<?php
require_once 'config/database.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get all skills for the dropdown
$stmt = $pdo->prepare("SELECT * FROM skills ORDER BY skill_name");
$stmt->execute();
$all_skills = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo->beginTransaction();

        // Insert portfolio item
        $stmt = $pdo->prepare("
            INSERT INTO portfolio_items (user_id, title, description, image_url, project_url, completion_date)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $user_id,
            $_POST['title'],
            $_POST['description'],
            $_POST['image_url'],
            $_POST['project_url'],
            $_POST['completion_date']
        ]);

        $portfolio_id = $pdo->lastInsertId();

        // Insert skills
        if (!empty($_POST['skills'])) {
            $skill_stmt = $pdo->prepare("
                INSERT INTO portfolio_skills (portfolio_id, skill_id)
                VALUES (?, ?)
            ");
            foreach ($_POST['skills'] as $skill_id) {
                $skill_stmt->execute([$portfolio_id, $skill_id]);
            }
        }

        $pdo->commit();
        header("Location: portfolio.php");
        exit();
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Error adding portfolio item: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Portfolio Item - Career Roadmap</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Add Portfolio Item</h4>
                    </div>
                    <div class="card-body">
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>

                        <form method="POST" class="needs-validation" novalidate>
                            <div class="mb-3">
                                <label for="title" class="form-label">Project Title</label>
                                <input type="text" class="form-control" id="title" name="title" required>
                            </div>

                            <div class="mb-3">
                                <label for="description" class="form-label">Project Description</label>
                                <textarea class="form-control" id="description" name="description" rows="4" required></textarea>
                            </div>

                            <div class="mb-3">
                                <label for="image_url" class="form-label">Project Image URL</label>
                                <input type="url" class="form-control" id="image_url" name="image_url">
                                <small class="text-muted">Optional: Link to a screenshot or preview image</small>
                            </div>

                            <div class="mb-3">
                                <label for="project_url" class="form-label">Project URL</label>
                                <input type="url" class="form-control" id="project_url" name="project_url">
                                <small class="text-muted">Optional: Link to the live project or repository</small>
                            </div>

                            <div class="mb-3">
                                <label for="completion_date" class="form-label">Completion Date</label>
                                <input type="date" class="form-control" id="completion_date" name="completion_date" required>
                            </div>

                            <div class="mb-3">
                                <label for="skills" class="form-label">Skills Used</label>
                                <select class="form-control select2" id="skills" name="skills[]" multiple required>
                                    <?php foreach ($all_skills as $skill): ?>
                                        <option value="<?php echo $skill['id']; ?>">
                                            <?php echo htmlspecialchars($skill['skill_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">Add Project</button>
                                <a href="portfolio.php" class="btn btn-secondary">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            // Initialize Select2
            $('.select2').select2({
                placeholder: 'Select skills used in this project',
                allowClear: true
            });

            // Form validation
            (function () {
                'use strict'
                var forms = document.querySelectorAll('.needs-validation')
                Array.prototype.slice.call(forms)
                    .forEach(function (form) {
                        form.addEventListener('submit', function (event) {
                            if (!form.checkValidity()) {
                                event.preventDefault()
                                event.stopPropagation()
                            }
                            form.classList.add('was-validated')
                        }, false)
                    })
            })()
        });
    </script>
</body>
</html> 