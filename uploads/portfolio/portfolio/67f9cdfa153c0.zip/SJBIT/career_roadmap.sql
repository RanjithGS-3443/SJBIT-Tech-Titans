-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2025 at 09:45 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `career_roadmap`
--

-- --------------------------------------------------------

--
-- Table structure for table `career_goals`
--

CREATE TABLE `career_goals` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `required_skills` text DEFAULT NULL,
  `estimated_time` varchar(50) DEFAULT NULL,
  `salary_range` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `career_goals`
--

INSERT INTO `career_goals` (`id`, `name`, `description`, `required_skills`, `estimated_time`, `salary_range`) VALUES
(1, 'Web Developer', 'Front-end and back-end web development', 'HTML,CSS,JavaScript', '6-12 months', '$50,000 - $100,000'),
(2, 'Data Analyst', 'Data analysis and visualization', 'Python,Data Analysis', '4-8 months', '$45,000 - $85,000'),
(3, 'Machine Learning Engineer', 'Building ML models and systems', 'Python,Machine Learning', '12-18 months', '$80,000 - $150,000');

-- --------------------------------------------------------

--
-- Table structure for table `chat_history`
--

CREATE TABLE `chat_history` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `response` text NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `portfolio_items`
--

CREATE TABLE `portfolio_items` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `project_url` varchar(255) DEFAULT NULL,
  `completion_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `portfolio_skills`
--

CREATE TABLE `portfolio_skills` (
  `portfolio_id` int(11) NOT NULL,
  `skill_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `progress`
--

CREATE TABLE `progress` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `roadmap_id` int(11) NOT NULL,
  `completion_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quiz_questions`
--

CREATE TABLE `quiz_questions` (
  `id` int(11) NOT NULL,
  `skill_id` int(11) NOT NULL,
  `question_text` text NOT NULL,
  `question_type` enum('multiple_choice','true_false') NOT NULL,
  `correct_answer` varchar(255) NOT NULL,
  `options` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quiz_questions`
--

INSERT INTO `quiz_questions` (`id`, `skill_id`, `question_text`, `question_type`, `correct_answer`, `options`, `created_at`) VALUES
(1, 1, 'What is encapsulation in OOP?', 'multiple_choice', 'Bundling data and methods that operate on that data within a single unit', '{\"options\": [\"Bundling data and methods that operate on that data within a single unit\", \"Creating multiple classes\", \"Writing clean code\", \"Using global variables\"]}', '2025-04-11 13:02:14'),
(2, 1, 'What is inheritance in OOP?', 'multiple_choice', 'A mechanism that allows a class to inherit properties and methods from another class', '{\"options\": [\"A mechanism that allows a class to inherit properties and methods from another class\", \"Creating objects\", \"Writing functions\", \"Using variables\"]}', '2025-04-11 13:02:14'),
(3, 1, 'What is polymorphism in OOP?', 'multiple_choice', 'The ability of different classes to be treated as instances of the same class through base class inheritance', '{\"options\": [\"The ability of different classes to be treated as instances of the same class through base class inheritance\", \"Creating multiple objects\", \"Using different variables\", \"Writing multiple functions\"]}', '2025-04-11 13:02:14'),
(4, 1, 'What is abstraction in OOP?', 'multiple_choice', 'Hiding complex implementation details and showing only necessary features of an object', '{\"options\": [\"Hiding complex implementation details and showing only necessary features of an object\", \"Using concrete classes\", \"Creating objects\", \"Writing code\"]}', '2025-04-11 13:02:14'),
(5, 1, 'What is a constructor?', 'multiple_choice', 'A special method that is automatically called when an object is created', '{\"options\": [\"A special method that is automatically called when an object is created\", \"A regular method\", \"A variable\", \"A class name\"]}', '2025-04-11 13:02:14'),
(6, 1, 'What is method overriding?', 'multiple_choice', 'Providing a specific implementation of a method in a subclass that is already defined in its parent class', '{\"options\": [\"Providing a specific implementation of a method in a subclass that is already defined in its parent class\", \"Creating new methods\", \"Deleting methods\", \"Renaming methods\"]}', '2025-04-11 13:02:14'),
(7, 1, 'What is an interface in OOP?', 'multiple_choice', 'A contract that specifies what methods a class must implement', '{\"options\": [\"A contract that specifies what methods a class must implement\", \"A concrete class\", \"A variable type\", \"A method name\"]}', '2025-04-11 13:02:14'),
(8, 1, 'What is the difference between composition and inheritance?', 'multiple_choice', 'Composition is a has-a relationship while inheritance is an is-a relationship', '{\"options\": [\"Composition is a has-a relationship while inheritance is an is-a relationship\", \"They are the same thing\", \"Composition is faster than inheritance\", \"Inheritance is newer than composition\"]}', '2025-04-11 13:02:14'),
(9, 1, 'What is a static method?', 'multiple_choice', 'A method that belongs to the class rather than an instance of the class', '{\"options\": [\"A method that belongs to the class rather than an instance of the class\", \"A private method\", \"A public method\", \"An instance method\"]}', '2025-04-11 13:02:14'),
(10, 1, 'What is the purpose of the final keyword in OOP?', 'multiple_choice', 'To prevent inheritance and method overriding', '{\"options\": [\"To prevent inheritance and method overriding\", \"To create objects\", \"To declare variables\", \"To write methods\"]}', '2025-04-11 13:02:14'),
(11, 2, 'What is the time complexity of searching in a binary search tree?', 'multiple_choice', 'O(log n)', '{\"options\": [\"O(log n)\", \"O(n)\", \"O(1)\", \"O(n^2)\"]}', '2025-04-11 13:02:14'),
(12, 2, 'What is a hash table collision?', 'multiple_choice', 'When two different keys hash to the same index', '{\"options\": [\"When two different keys hash to the same index\", \"When a key is not found\", \"When the table is full\", \"When the hash function fails\"]}', '2025-04-11 13:02:14'),
(13, 2, 'What is the main advantage of a linked list over an array?', 'multiple_choice', 'Dynamic size and efficient insertion/deletion', '{\"options\": [\"Dynamic size and efficient insertion/deletion\", \"Faster access time\", \"Less memory usage\", \"Better cache performance\"]}', '2025-04-11 13:02:14'),
(14, 2, 'What is a stack used for?', 'multiple_choice', 'Managing function calls and undo operations', '{\"options\": [\"Managing function calls and undo operations\", \"Sorting data\", \"Searching elements\", \"Storing data permanently\"]}', '2025-04-11 13:02:14'),
(15, 2, 'What is the time complexity of quicksort in the worst case?', 'multiple_choice', 'O(n^2)', '{\"options\": [\"O(n^2)\", \"O(n)\", \"O(log n)\", \"O(n log n)\"]}', '2025-04-11 13:02:14'),
(16, 2, 'What is a queue used for?', 'multiple_choice', 'Managing tasks in order of arrival', '{\"options\": [\"Managing tasks in order of arrival\", \"Storing sorted data\", \"Quick searching\", \"Memory management\"]}', '2025-04-11 13:02:14'),
(17, 2, 'What is a binary heap?', 'multiple_choice', 'A complete binary tree with heap property', '{\"options\": [\"A complete binary tree with heap property\", \"A linked list\", \"A sorting algorithm\", \"A search tree\"]}', '2025-04-11 13:02:14'),
(18, 2, 'What is the space complexity of a binary search tree?', 'multiple_choice', 'O(n)', '{\"options\": [\"O(n)\", \"O(1)\", \"O(log n)\", \"O(n^2)\"]}', '2025-04-11 13:02:14'),
(19, 2, 'What is a graph used for?', 'multiple_choice', 'Representing relationships between objects', '{\"options\": [\"Representing relationships between objects\", \"Storing sorted data\", \"Quick searching\", \"Memory management\"]}', '2025-04-11 13:02:14'),
(20, 2, 'What is the difference between BFS and DFS?', 'multiple_choice', 'BFS explores breadth-wise while DFS explores depth-wise', '{\"options\": [\"BFS explores breadth-wise while DFS explores depth-wise\", \"They are the same\", \"BFS is always faster\", \"DFS uses less memory\"]}', '2025-04-11 13:02:14'),
(21, 3, 'What is dynamic programming?', 'multiple_choice', 'Solving complex problems by breaking them into simpler subproblems', '{\"options\": [\"Solving complex problems by breaking them into simpler subproblems\", \"Writing dynamic code\", \"Using multiple loops\", \"Creating dynamic arrays\"]}', '2025-04-11 13:02:14'),
(22, 3, 'What is the difference between greedy and dynamic programming algorithms?', 'multiple_choice', 'Greedy makes locally optimal choices while dynamic programming finds global optimal', '{\"options\": [\"Greedy makes locally optimal choices while dynamic programming finds global optimal\", \"They are the same\", \"Greedy is always faster\", \"Dynamic programming uses less memory\"]}', '2025-04-11 13:02:14'),
(23, 3, 'What is the time complexity of binary search?', 'multiple_choice', 'O(log n)', '{\"options\": [\"O(log n)\", \"O(n)\", \"O(1)\", \"O(n^2)\"]}', '2025-04-11 13:02:14'),
(24, 3, 'What is a divide and conquer algorithm?', 'multiple_choice', 'An algorithm that breaks a problem into smaller subproblems, solves them, and combines the results', '{\"options\": [\"An algorithm that breaks a problem into smaller subproblems, solves them, and combines the results\", \"An algorithm that uses loops\", \"A sorting algorithm\", \"A searching algorithm\"]}', '2025-04-11 13:02:14'),
(25, 3, 'What is the purpose of Big O notation?', 'multiple_choice', 'To describe the upper bound of the growth rate of an algorithm', '{\"options\": [\"To describe the upper bound of the growth rate of an algorithm\", \"To measure code quality\", \"To count lines of code\", \"To measure memory usage\"]}', '2025-04-11 13:02:14'),
(26, 3, 'What is recursion?', 'multiple_choice', 'A function calling itself to solve a smaller instance of the same problem', '{\"options\": [\"A function calling itself to solve a smaller instance of the same problem\", \"Using multiple loops\", \"Creating objects\", \"Writing iterative code\"]}', '2025-04-11 13:02:14'),
(27, 3, 'What is memoization?', 'multiple_choice', 'Storing results of expensive function calls to avoid redundant computations', '{\"options\": [\"Storing results of expensive function calls to avoid redundant computations\", \"Writing comments\", \"Using memory\", \"Creating variables\"]}', '2025-04-11 13:02:14'),
(28, 3, 'What is the time complexity of bubble sort?', 'multiple_choice', 'O(n^2)', '{\"options\": [\"O(n^2)\", \"O(n)\", \"O(log n)\", \"O(n log n)\"]}', '2025-04-11 13:02:14'),
(29, 3, 'What is an in-place algorithm?', 'multiple_choice', 'An algorithm that transforms input using no extra space or O(1) extra space', '{\"options\": [\"An algorithm that transforms input using no extra space or O(1) extra space\", \"An algorithm that uses extra space\", \"A fast algorithm\", \"A recursive algorithm\"]}', '2025-04-11 13:02:14'),
(30, 3, 'What is the difference between stable and unstable sorting algorithms?', 'multiple_choice', 'Stable sort maintains relative order of equal elements while unstable sort might not', '{\"options\": [\"Stable sort maintains relative order of equal elements while unstable sort might not\", \"Stable sort is faster\", \"Unstable sort uses less memory\", \"They are the same\"]}', '2025-04-11 13:02:14'),
(31, 4, 'What is normalization in database design?', 'multiple_choice', 'The process of organizing data to minimize redundancy', '{\"options\": [\"The process of organizing data to minimize redundancy\", \"Creating tables\", \"Writing queries\", \"Adding indexes\"]}', '2025-04-11 13:02:14'),
(32, 4, 'What is a primary key?', 'multiple_choice', 'A column or combination of columns that uniquely identifies each row', '{\"options\": [\"A column or combination of columns that uniquely identifies each row\", \"Any column in a table\", \"A foreign key\", \"An index\"]}', '2025-04-11 13:02:14'),
(33, 4, 'What is a foreign key?', 'multiple_choice', 'A column that creates a relationship between two tables', '{\"options\": [\"A column that creates a relationship between two tables\", \"A primary key\", \"An index\", \"A constraint\"]}', '2025-04-11 13:02:14'),
(34, 4, 'What is an index in a database?', 'multiple_choice', 'A data structure that improves the speed of data retrieval', '{\"options\": [\"A data structure that improves the speed of data retrieval\", \"A table column\", \"A primary key\", \"A foreign key\"]}', '2025-04-11 13:02:14'),
(35, 4, 'What is ACID in database transactions?', 'multiple_choice', 'Atomicity, Consistency, Isolation, Durability', '{\"options\": [\"Atomicity, Consistency, Isolation, Durability\", \"A type of query\", \"A database design pattern\", \"A constraint type\"]}', '2025-04-11 13:02:14'),
(36, 4, 'What is denormalization?', 'multiple_choice', 'Adding redundant data to improve query performance', '{\"options\": [\"Adding redundant data to improve query performance\", \"Removing data\", \"Normalizing data\", \"Creating indexes\"]}', '2025-04-11 13:02:14'),
(37, 4, 'What is a stored procedure?', 'multiple_choice', 'A prepared SQL code that can be saved and reused', '{\"options\": [\"A prepared SQL code that can be saved and reused\", \"A table type\", \"A column constraint\", \"A data type\"]}', '2025-04-11 13:02:14'),
(38, 4, 'What is a trigger in a database?', 'multiple_choice', 'A special procedure that automatically runs when certain events occur', '{\"options\": [\"A special procedure that automatically runs when certain events occur\", \"A type of query\", \"A table constraint\", \"A data validation\"]}', '2025-04-11 13:02:14'),
(39, 4, 'What is the difference between INNER and LEFT JOIN?', 'multiple_choice', 'INNER JOIN returns matching rows while LEFT JOIN includes all rows from the left table', '{\"options\": [\"INNER JOIN returns matching rows while LEFT JOIN includes all rows from the left table\", \"They are the same\", \"INNER JOIN is faster\", \"LEFT JOIN uses less memory\"]}', '2025-04-11 13:02:14'),
(40, 4, 'What is database sharding?', 'multiple_choice', 'Splitting a database into smaller parts across multiple servers', '{\"options\": [\"Splitting a database into smaller parts across multiple servers\", \"Creating backups\", \"Adding indexes\", \"Writing queries\"]}', '2025-04-11 13:02:14'),
(41, 5, 'What is responsive web design?', 'multiple_choice', 'Design that adapts to different screen sizes and devices', '{\"options\": [\"Design that adapts to different screen sizes and devices\", \"Fast loading websites\", \"Using JavaScript\", \"Writing HTML\"]}', '2025-04-11 13:02:14'),
(42, 5, 'What is the difference between HTTP and HTTPS?', 'multiple_choice', 'HTTPS is secure and encrypted while HTTP is not', '{\"options\": [\"HTTPS is secure and encrypted while HTTP is not\", \"They are the same\", \"HTTP is newer\", \"HTTPS is faster\"]}', '2025-04-11 13:02:14'),
(43, 5, 'What is AJAX?', 'multiple_choice', 'Asynchronous JavaScript and XML for updating parts of a web page', '{\"options\": [\"Asynchronous JavaScript and XML for updating parts of a web page\", \"A programming language\", \"A database\", \"A web server\"]}', '2025-04-11 13:02:14'),
(44, 5, 'What is CSS flexbox?', 'multiple_choice', 'A layout model for arranging elements in a flexible way', '{\"options\": [\"A layout model for arranging elements in a flexible way\", \"A JavaScript framework\", \"A database type\", \"A programming language\"]}', '2025-04-11 13:02:14'),
(45, 5, 'What is the purpose of a REST API?', 'multiple_choice', 'To provide a standardized way for applications to communicate over HTTP', '{\"options\": [\"To provide a standardized way for applications to communicate over HTTP\", \"To create databases\", \"To style web pages\", \"To write JavaScript\"]}', '2025-04-11 13:02:14'),
(46, 5, 'What is the difference between GET and POST methods?', 'multiple_choice', 'GET retrieves data while POST submits data', '{\"options\": [\"GET retrieves data while POST submits data\", \"They are the same\", \"GET is faster\", \"POST is more secure\"]}', '2025-04-11 13:02:14'),
(47, 5, 'What is Cross-Origin Resource Sharing (CORS)?', 'multiple_choice', 'A security feature that controls how web pages access resources from different domains', '{\"options\": [\"A security feature that controls how web pages access resources from different domains\", \"A programming language\", \"A database type\", \"A web server\"]}', '2025-04-11 13:02:14'),
(48, 5, 'What is the purpose of localStorage?', 'multiple_choice', 'To store data persistently in a web browser', '{\"options\": [\"To store data persistently in a web browser\", \"To create databases\", \"To style web pages\", \"To write JavaScript\"]}', '2025-04-11 13:02:14'),
(49, 5, 'What is a web socket?', 'multiple_choice', 'A protocol for full-duplex communication between client and server', '{\"options\": [\"A protocol for full-duplex communication between client and server\", \"A database connection\", \"A CSS property\", \"An HTML element\"]}', '2025-04-11 13:02:14'),
(50, 5, 'What is the purpose of a CDN?', 'multiple_choice', 'To deliver content to users from the nearest server location', '{\"options\": [\"To deliver content to users from the nearest server location\", \"To create websites\", \"To write code\", \"To store data\"]}', '2025-04-11 13:02:14'),
(51, 6, 'What is the purpose of exploratory data analysis (EDA)?', 'multiple_choice', 'To understand data patterns and relationships before formal modeling', '{\"options\": [\"To understand data patterns and relationships before formal modeling\", \"To clean data only\", \"To create visualizations only\", \"To build machine learning models\"]}', '2025-04-11 13:02:14'),
(52, 6, 'Which measure of central tendency is most sensitive to outliers?', 'multiple_choice', 'Mean', '{\"options\": [\"Mean\", \"Median\", \"Mode\", \"Range\"]}', '2025-04-11 13:02:14'),
(53, 6, 'What is the purpose of data normalization?', 'multiple_choice', 'To scale features to a similar range for fair comparison', '{\"options\": [\"To scale features to a similar range for fair comparison\", \"To remove data\", \"To create new features\", \"To fix missing values\"]}', '2025-04-11 13:02:14'),
(54, 6, 'What is a correlation coefficient used for?', 'multiple_choice', 'To measure the strength and direction of relationship between variables', '{\"options\": [\"To measure the strength and direction of relationship between variables\", \"To predict future values\", \"To clean data\", \"To create graphs\"]}', '2025-04-11 13:02:14'),
(55, 6, 'What is the difference between variance and standard deviation?', 'multiple_choice', 'Standard deviation is the square root of variance', '{\"options\": [\"Standard deviation is the square root of variance\", \"They are the same thing\", \"Variance is always larger\", \"Standard deviation is always larger\"]}', '2025-04-11 13:02:14'),
(56, 6, 'What is the purpose of hypothesis testing?', 'multiple_choice', 'To make statistical decisions using experimental data', '{\"options\": [\"To make statistical decisions using experimental data\", \"To clean data\", \"To create visualizations\", \"To build models\"]}', '2025-04-11 13:02:14'),
(57, 6, 'What is the difference between population and sample?', 'multiple_choice', 'A sample is a subset of the population', '{\"options\": [\"A sample is a subset of the population\", \"They are the same thing\", \"Population is smaller than sample\", \"Sample contains all data\"]}', '2025-04-11 13:02:14'),
(58, 6, 'What is the purpose of a box plot?', 'multiple_choice', 'To show distribution, median, quartiles, and potential outliers', '{\"options\": [\"To show distribution, median, quartiles, and potential outliers\", \"To show only mean values\", \"To predict future values\", \"To clean data\"]}', '2025-04-11 13:02:14'),
(59, 6, 'What is the difference between categorical and numerical data?', 'multiple_choice', 'Categorical data represents groups while numerical data represents quantities', '{\"options\": [\"Categorical data represents groups while numerical data represents quantities\", \"They are the same\", \"Categorical data is always numeric\", \"Numerical data cannot be counted\"]}', '2025-04-11 13:02:14'),
(60, 6, 'What is the purpose of feature engineering?', 'multiple_choice', 'To create new meaningful features from existing data', '{\"options\": [\"To create new meaningful features from existing data\", \"To remove features\", \"To only clean data\", \"To create visualizations\"]}', '2025-04-11 13:02:14');

-- --------------------------------------------------------

--
-- Table structure for table `quiz_results`
--

CREATE TABLE `quiz_results` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `skill_id` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `total_questions` int(11) NOT NULL,
  `percentage` decimal(5,2) NOT NULL,
  `level` enum('beginner','intermediate','advanced') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quiz_results`
--

INSERT INTO `quiz_results` (`id`, `user_id`, `skill_id`, `score`, `total_questions`, `percentage`, `level`, `created_at`) VALUES
(1, 5, 6, 4, 10, 40.00, 'beginner', '2025-04-11 14:13:27'),
(2, 6, 6, 4, 10, 40.00, 'beginner', '2025-04-11 17:25:13');

-- --------------------------------------------------------

--
-- Table structure for table `resources`
--

CREATE TABLE `resources` (
  `id` int(11) NOT NULL,
  `skill_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('video','pdf') NOT NULL,
  `url` varchar(255) NOT NULL,
  `thumbnail_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `resources`
--

INSERT INTO `resources` (`id`, `skill_id`, `title`, `description`, `type`, `url`, `thumbnail_url`, `created_at`) VALUES
(1, 1, 'Object-Oriented Programming in Python', 'Complete guide to OOP concepts in Python', 'video', 'https://www.youtube.com/watch?v=ZDa-Z5JzLYM', 'https://img.youtube.com/vi/ZDa-Z5JzLYM/0.jpg', '2025-04-11 13:02:14'),
(2, 1, 'Java OOP Made Easy', 'Learn OOP concepts with practical examples', 'video', 'https://www.youtube.com/watch?v=pTB0EiLXUC8', 'https://img.youtube.com/vi/pTB0EiLXUC8/0.jpg', '2025-04-11 13:02:14'),
(3, 1, 'C++ Object-Oriented Programming', 'Master OOP in C++ with real-world examples', 'video', 'https://www.youtube.com/watch?v=wN0x9eZLix4', 'https://img.youtube.com/vi/wN0x9eZLix4/0.jpg', '2025-04-11 13:02:14'),
(4, 1, 'SOLID Principles Made Easy', 'Understanding SOLID principles in OOP', 'video', 'https://www.youtube.com/watch?v=rtmFCcjEgEw', 'https://img.youtube.com/vi/rtmFCcjEgEw/0.jpg', '2025-04-11 13:02:14'),
(5, 1, 'Design Patterns Tutorial', 'Learn common design patterns in OOP', 'video', 'https://www.youtube.com/watch?v=v9ejT8FO-7I', 'https://img.youtube.com/vi/v9ejT8FO-7I/0.jpg', '2025-04-11 13:02:14'),
(6, 1, 'OOP Design Patterns Guide', 'Comprehensive PDF guide to design patterns', 'pdf', 'assets/resources/design-patterns.pdf', NULL, '2025-04-11 13:02:14'),
(7, 1, 'Clean Code in OOP', 'Best practices for writing clean OOP code', 'pdf', 'assets/resources/clean-code-oop.pdf', NULL, '2025-04-11 13:02:14'),
(8, 1, 'SOLID Principles Handbook', 'Detailed guide to SOLID principles', 'pdf', 'assets/resources/solid-principles.pdf', NULL, '2025-04-11 13:02:14'),
(9, 2, 'Data Structures Fundamentals', 'Learn basic data structures implementation', 'video', 'https://www.youtube.com/watch?v=RBSGKlAvoiM', 'https://img.youtube.com/vi/RBSGKlAvoiM/0.jpg', '2025-04-11 13:02:14'),
(10, 2, 'Binary Trees and BST', 'Understanding tree data structures', 'video', 'https://www.youtube.com/watch?v=fAAZixBzIAI', 'https://img.youtube.com/vi/fAAZixBzIAI/0.jpg', '2025-04-11 13:02:14'),
(11, 2, 'Hash Tables Explained', 'Deep dive into hash tables and hashing', 'video', 'https://www.youtube.com/watch?v=shs0KM3wKv8', 'https://img.youtube.com/vi/shs0KM3wKv8/0.jpg', '2025-04-11 13:02:14'),
(12, 2, 'Graph Data Structures', 'Complete guide to graph implementations', 'video', 'https://www.youtube.com/watch?v=tWVWeAqZ0WU', 'https://img.youtube.com/vi/tWVWeAqZ0WU/0.jpg', '2025-04-11 13:02:14'),
(13, 2, 'Advanced Data Structures', 'Deep dive into complex data structures', 'pdf', 'assets/resources/advanced-ds.pdf', NULL, '2025-04-11 13:02:14'),
(14, 2, 'Time Complexity Analysis', 'Guide to analyzing data structure operations', 'pdf', 'assets/resources/time-complexity.pdf', NULL, '2025-04-11 13:02:14'),
(15, 2, 'Data Structures Interview Guide', 'Common interview problems and solutions', 'pdf', 'assets/resources/ds-interview.pdf', NULL, '2025-04-11 13:02:14'),
(16, 3, 'Introduction to Algorithms', 'Basic algorithm concepts and analysis', 'video', 'https://www.youtube.com/watch?v=0IAPZzGSbME', 'https://img.youtube.com/vi/0IAPZzGSbME/0.jpg', '2025-04-11 13:02:14'),
(17, 3, 'Sorting Algorithms Visualized', 'Visual guide to common sorting algorithms', 'video', 'https://www.youtube.com/watch?v=kPRA0W1kECg', 'https://img.youtube.com/vi/kPRA0W1kECg/0.jpg', '2025-04-11 13:02:14'),
(18, 3, 'Dynamic Programming', 'Master dynamic programming techniques', 'video', 'https://www.youtube.com/watch?v=oBt53YbR9Kk', 'https://img.youtube.com/vi/oBt53YbR9Kk/0.jpg', '2025-04-11 13:02:14'),
(19, 3, 'Graph Algorithms', 'Understanding graph traversal and shortest paths', 'video', 'https://www.youtube.com/watch?v=tWVWeAqZ0WU', 'https://img.youtube.com/vi/tWVWeAqZ0WU/0.jpg', '2025-04-11 13:02:14'),
(20, 3, 'Algorithm Design Manual', 'Complete guide to algorithm design', 'pdf', 'assets/resources/algo-design.pdf', NULL, '2025-04-11 13:02:14'),
(21, 3, 'Dynamic Programming Guide', 'Comprehensive guide to DP problems', 'pdf', 'assets/resources/dp-guide.pdf', NULL, '2025-04-11 13:02:14'),
(22, 3, 'Algorithm Analysis Handbook', 'Deep dive into algorithm complexity', 'pdf', 'assets/resources/algo-analysis.pdf', NULL, '2025-04-11 13:02:14'),
(23, 4, 'SQL Database Design', 'Learn database design principles', 'video', 'https://www.youtube.com/watch?v=HXV3zeQKqGY', 'https://img.youtube.com/vi/HXV3zeQKqGY/0.jpg', '2025-04-11 13:02:14'),
(24, 4, 'NoSQL Databases', 'Understanding NoSQL database systems', 'video', 'https://www.youtube.com/watch?v=xQnIN9bW0og', 'https://img.youtube.com/vi/xQnIN9bW0og/0.jpg', '2025-04-11 13:02:14'),
(25, 4, 'Database Indexing', 'Master database indexing strategies', 'video', 'https://www.youtube.com/watch?v=HubXt90MLfE', 'https://img.youtube.com/vi/HubXt90MLfE/0.jpg', '2025-04-11 13:02:14'),
(26, 4, 'Database Transactions', 'Understanding ACID properties', 'video', 'https://www.youtube.com/watch?v=5ZjhNTM8XU8', 'https://img.youtube.com/vi/5ZjhNTM8XU8/0.jpg', '2025-04-11 13:02:14'),
(27, 4, 'Database Optimization Guide', 'Tips and tricks for database optimization', 'pdf', 'assets/resources/db-optimization.pdf', NULL, '2025-04-11 13:02:14'),
(28, 4, 'SQL Best Practices', 'Guide to writing efficient SQL queries', 'pdf', 'assets/resources/sql-best-practices.pdf', NULL, '2025-04-11 13:02:14'),
(29, 4, 'Database Security Guide', 'Comprehensive guide to database security', 'pdf', 'assets/resources/db-security.pdf', NULL, '2025-04-11 13:02:14'),
(30, 5, 'Modern Web Development', 'Full stack web development tutorial', 'video', 'https://www.youtube.com/watch?v=Q33KBiDriJY', 'https://img.youtube.com/vi/Q33KBiDriJY/0.jpg', '2025-04-11 13:02:14'),
(31, 5, 'React.js Crash Course', 'Learn React.js fundamentals', 'video', 'https://www.youtube.com/watch?v=w7ejDZ8SWv8', 'https://img.youtube.com/vi/w7ejDZ8SWv8/0.jpg', '2025-04-11 13:02:14'),
(32, 5, 'Node.js Tutorial', 'Backend development with Node.js', 'video', 'https://www.youtube.com/watch?v=Oe421EPjeBE', 'https://img.youtube.com/vi/Oe421EPjeBE/0.jpg', '2025-04-11 13:02:14'),
(33, 5, 'REST API Design', 'Best practices for API development', 'video', 'https://www.youtube.com/watch?v=fgTGADljAeg', 'https://img.youtube.com/vi/fgTGADljAeg/0.jpg', '2025-04-11 13:02:14'),
(34, 5, 'Web Security Best Practices', 'Guide to securing web applications', 'pdf', 'assets/resources/web-security.pdf', NULL, '2025-04-11 13:02:14'),
(35, 5, 'Frontend Development Guide', 'Modern frontend development practices', 'pdf', 'assets/resources/frontend-guide.pdf', NULL, '2025-04-11 13:02:14'),
(36, 5, 'Web Performance Optimization', 'Techniques for faster web apps', 'pdf', 'assets/resources/web-performance.pdf', NULL, '2025-04-11 13:02:14'),
(37, 6, 'Data Analysis with Python', 'Learn data analysis using Python', 'video', 'https://www.youtube.com/watch?v=r-uOLxNrNk8', 'https://img.youtube.com/vi/r-uOLxNrNk8/0.jpg', '2025-04-11 13:02:14'),
(38, 6, 'Pandas Tutorial', 'Master data manipulation with Pandas', 'video', 'https://www.youtube.com/watch?v=vmEHCJofslg', 'https://img.youtube.com/vi/vmEHCJofslg/0.jpg', '2025-04-11 13:02:14'),
(39, 6, 'Data Visualization', 'Creating effective data visualizations', 'video', 'https://www.youtube.com/watch?v=a9UrKTVEeZA', 'https://img.youtube.com/vi/a9UrKTVEeZA/0.jpg', '2025-04-11 13:02:14'),
(40, 6, 'Statistical Analysis', 'Understanding statistical methods', 'video', 'https://www.youtube.com/watch?v=xxpc-HPKN28', 'https://img.youtube.com/vi/xxpc-HPKN28/0.jpg', '2025-04-11 13:02:14'),
(41, 6, 'Statistical Analysis Guide', 'Comprehensive guide to statistical analysis', 'pdf', 'assets/resources/stats-guide.pdf', NULL, '2025-04-11 13:02:14'),
(42, 6, 'Data Cleaning Techniques', 'Guide to preparing data for analysis', 'pdf', 'assets/resources/data-cleaning.pdf', NULL, '2025-04-11 13:02:14'),
(43, 6, 'Machine Learning Basics', 'Introduction to ML concepts', 'pdf', 'assets/resources/ml-basics.pdf', NULL, '2025-04-11 13:02:14');

-- --------------------------------------------------------

--
-- Table structure for table `roadmap`
--

CREATE TABLE `roadmap` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `week` int(11) NOT NULL,
  `task_description` text NOT NULL,
  `resource_id` int(11) DEFAULT NULL,
  `status` enum('pending','in_progress','completed') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roadmap`
--

INSERT INTO `roadmap` (`id`, `user_id`, `week`, `task_description`, `resource_id`, `status`) VALUES
(13009, 6, 1, 'Apply HTML in real-world scenarios', NULL, 'pending'),
(13010, 6, 1, 'Apply HTML in real-world scenarios', NULL, 'pending'),
(13011, 6, 2, 'Apply HTML in real-world scenarios', NULL, 'pending'),
(13012, 6, 2, 'Learn fundamentals of HTML', NULL, 'pending'),
(13013, 6, 3, 'Practice HTML through exercises', NULL, 'pending'),
(13014, 6, 3, 'Review and reinforce HTML concepts', NULL, 'pending'),
(13015, 6, 3, 'Work on HTML projects', NULL, 'pending'),
(13016, 6, 4, 'Work on HTML projects', NULL, 'pending'),
(13017, 6, 4, 'Review and reinforce HTML concepts', NULL, 'pending'),
(13018, 6, 4, 'Apply HTML in real-world scenarios', NULL, 'pending'),
(13019, 6, 5, 'Work on HTML projects', NULL, 'pending'),
(13020, 6, 5, 'Review and reinforce HTML concepts', NULL, 'pending'),
(13021, 6, 6, 'Apply HTML in real-world scenarios', NULL, 'pending'),
(13022, 6, 6, 'Practice HTML through exercises', NULL, 'pending'),
(13023, 6, 7, 'Work on HTML projects', NULL, 'pending'),
(13024, 6, 7, 'Review and reinforce HTML concepts', NULL, 'pending'),
(13025, 6, 8, 'Apply HTML in real-world scenarios', NULL, 'pending'),
(13026, 6, 8, 'Work on HTML projects', NULL, 'pending'),
(13027, 6, 9, 'Work on HTML projects', NULL, 'pending'),
(13028, 6, 9, 'Apply HTML in real-world scenarios', NULL, 'pending'),
(13029, 6, 10, 'Apply HTML in real-world scenarios', NULL, 'pending'),
(13030, 6, 10, 'Review and reinforce HTML concepts', NULL, 'pending'),
(13031, 6, 11, 'Work on HTML projects', NULL, 'pending'),
(13032, 6, 11, 'Review and reinforce HTML concepts', NULL, 'pending'),
(13033, 6, 11, 'Practice HTML through exercises', NULL, 'pending'),
(13034, 6, 12, 'Review and reinforce HTML concepts', NULL, 'pending'),
(13035, 6, 12, 'Apply HTML in real-world scenarios', NULL, 'pending'),
(13036, 6, 12, 'Apply HTML in real-world scenarios', NULL, 'pending'),
(13037, 6, 13, 'Review and reinforce CSS concepts', NULL, 'pending'),
(13038, 6, 13, 'Learn fundamentals of CSS', NULL, 'pending'),
(13039, 6, 13, 'Review and reinforce CSS concepts', NULL, 'pending'),
(13040, 6, 14, 'Work on CSS projects', NULL, 'pending'),
(13041, 6, 14, 'Practice CSS through exercises', NULL, 'pending'),
(13042, 6, 14, 'Review and reinforce CSS concepts', NULL, 'pending'),
(13043, 6, 15, 'Learn fundamentals of CSS', NULL, 'pending'),
(13044, 6, 15, 'Learn fundamentals of CSS', NULL, 'pending'),
(13045, 6, 16, 'Learn fundamentals of CSS', NULL, 'pending'),
(13046, 6, 16, 'Learn fundamentals of CSS', NULL, 'pending'),
(13047, 6, 17, 'Review and reinforce CSS concepts', NULL, 'pending'),
(13048, 6, 17, 'Apply CSS in real-world scenarios', NULL, 'pending'),
(13049, 6, 18, 'Learn fundamentals of CSS', NULL, 'pending'),
(13050, 6, 18, 'Work on CSS projects', NULL, 'pending'),
(13051, 6, 18, 'Learn fundamentals of CSS', NULL, 'pending'),
(13052, 6, 19, 'Apply CSS in real-world scenarios', NULL, 'pending'),
(13053, 6, 19, 'Learn fundamentals of CSS', NULL, 'pending'),
(13054, 6, 20, 'Review and reinforce CSS concepts', NULL, 'pending'),
(13055, 6, 20, 'Practice CSS through exercises', NULL, 'pending'),
(13056, 6, 20, 'Work on CSS projects', NULL, 'pending'),
(13057, 6, 21, 'Review and reinforce CSS concepts', NULL, 'pending'),
(13058, 6, 21, 'Work on CSS projects', NULL, 'pending'),
(13059, 6, 22, 'Practice CSS through exercises', NULL, 'pending'),
(13060, 6, 22, 'Apply CSS in real-world scenarios', NULL, 'pending'),
(13061, 6, 22, 'Learn fundamentals of CSS', NULL, 'pending'),
(13062, 6, 23, 'Practice CSS through exercises', NULL, 'pending'),
(13063, 6, 23, 'Learn fundamentals of CSS', NULL, 'pending'),
(13064, 6, 23, 'Review and reinforce CSS concepts', NULL, 'pending'),
(13065, 6, 24, 'Learn fundamentals of CSS', NULL, 'pending'),
(13066, 6, 24, 'Apply CSS in real-world scenarios', NULL, 'pending'),
(13067, 6, 25, 'Review and reinforce JavaScript concepts', NULL, 'pending'),
(13068, 6, 25, 'Review and reinforce JavaScript concepts', NULL, 'pending'),
(13069, 6, 25, 'Practice JavaScript through exercises', NULL, 'pending'),
(13070, 6, 26, 'Learn fundamentals of JavaScript', NULL, 'pending'),
(13071, 6, 26, 'Practice JavaScript through exercises', NULL, 'pending'),
(13072, 6, 26, 'Work on JavaScript projects', NULL, 'pending'),
(13073, 6, 27, 'Apply JavaScript in real-world scenarios', NULL, 'pending'),
(13074, 6, 27, 'Review and reinforce JavaScript concepts', NULL, 'pending'),
(13075, 6, 27, 'Work on JavaScript projects', NULL, 'pending'),
(13076, 6, 28, 'Practice JavaScript through exercises', NULL, 'pending'),
(13077, 6, 28, 'Apply JavaScript in real-world scenarios', NULL, 'pending'),
(13078, 6, 28, 'Review and reinforce JavaScript concepts', NULL, 'pending'),
(13079, 6, 29, 'Learn fundamentals of JavaScript', NULL, 'pending'),
(13080, 6, 29, 'Practice JavaScript through exercises', NULL, 'pending'),
(13081, 6, 30, 'Practice JavaScript through exercises', NULL, 'pending'),
(13082, 6, 30, 'Learn fundamentals of JavaScript', NULL, 'pending'),
(13083, 6, 31, 'Work on JavaScript projects', NULL, 'pending'),
(13084, 6, 31, 'Work on JavaScript projects', NULL, 'pending'),
(13085, 6, 31, 'Practice JavaScript through exercises', NULL, 'pending'),
(13086, 6, 32, 'Review and reinforce JavaScript concepts', NULL, 'pending'),
(13087, 6, 32, 'Practice JavaScript through exercises', NULL, 'pending'),
(13088, 6, 33, 'Work on JavaScript projects', NULL, 'pending'),
(13089, 6, 33, 'Practice JavaScript through exercises', NULL, 'pending'),
(13090, 6, 34, 'Practice JavaScript through exercises', NULL, 'pending'),
(13091, 6, 34, 'Work on JavaScript projects', NULL, 'pending'),
(13092, 6, 35, 'Work on JavaScript projects', NULL, 'pending'),
(13093, 6, 35, 'Learn fundamentals of JavaScript', NULL, 'pending'),
(13094, 6, 36, 'Apply JavaScript in real-world scenarios', NULL, 'pending'),
(13095, 6, 36, 'Learn fundamentals of JavaScript', NULL, 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE `skills` (
  `id` int(11) NOT NULL,
  `skill_name` varchar(255) NOT NULL,
  `category` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`id`, `skill_name`, `category`, `description`, `created_at`) VALUES
(1, 'Object-Oriented Programming', 'Programming', 'Understanding of OOP concepts and principles', '2025-04-11 13:02:14'),
(2, 'Data Structures', 'Programming', 'Knowledge of fundamental data structures', '2025-04-11 13:02:14'),
(3, 'Algorithms', 'Programming', 'Understanding of algorithm design and analysis', '2025-04-11 13:02:14'),
(4, 'Database Design', 'Database', 'Skills in designing and optimizing databases', '2025-04-11 13:02:14'),
(5, 'Web Development', 'Web', 'Experience in building web applications', '2025-04-11 13:02:14'),
(6, 'Data Analysis', 'Data Science', 'Skills in analyzing and interpreting complex data sets', '2025-04-11 13:02:14');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `profile_photo` varchar(255) DEFAULT 'assets/img/default-profile.png',
  `resume_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`, `profile_photo`, `resume_path`) VALUES
(5, 'Kiran V', 'kiranv20042@gmail.com', '$2y$10$S9bbqykk4UoCHlQ/RjEiHu52XoJe7fCVAFXhdp5lnMuz0k3MWDNfW', '2025-04-11 11:52:00', 'uploads/profile_photos/profile_67f90260723a1.jpg', NULL),
(6, 'Anil BV', 'ania71904@gmail.com', '$2y$10$awjVLfHwF4mDQsYMS0NqzeOx14E6GbBG8u6Hiee7up4iSueeCCe4W', '2025-04-11 17:22:48', 'uploads/profile_photos/profile_67f94fe89f6cf.jpg', 'uploads/resumes/resume_6_1744392470.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `user_career_goals`
--

CREATE TABLE `user_career_goals` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `career_goal_id` int(11) NOT NULL,
  `target_date` date DEFAULT NULL,
  `status` enum('active','completed','abandoned') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_career_goals`
--

INSERT INTO `user_career_goals` (`id`, `user_id`, `career_goal_id`, `target_date`, `status`) VALUES
(5, 5, 2, '2026-02-02', 'active'),
(8, 6, 1, '2026-02-02', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `user_courses`
--

CREATE TABLE `user_courses` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `institution` varchar(255) NOT NULL,
  `completion_date` date NOT NULL,
  `certificate_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_courses`
--

INSERT INTO `user_courses` (`id`, `user_id`, `course_name`, `institution`, `completion_date`, `certificate_url`, `created_at`) VALUES
(1, 6, 'Basics of python', 'Infosys', '2024-02-02', '', '2025-04-11 17:29:06');

-- --------------------------------------------------------

--
-- Table structure for table `user_skills`
--

CREATE TABLE `user_skills` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `skill_id` int(11) NOT NULL,
  `level` enum('beginner','intermediate','advanced') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_skills`
--

INSERT INTO `user_skills` (`id`, `user_id`, `skill_id`, `level`, `created_at`) VALUES
(1, 5, 6, 'beginner', '2025-04-11 13:46:51'),
(2, 5, 4, 'beginner', '2025-04-11 13:46:51'),
(3, 5, 3, 'beginner', '2025-04-11 13:46:51'),
(4, 5, 2, 'beginner', '2025-04-11 13:46:51'),
(5, 5, 1, 'beginner', '2025-04-11 13:46:51'),
(6, 5, 5, 'beginner', '2025-04-11 13:46:51'),
(7, 5, 6, 'beginner', '2025-04-11 14:13:27'),
(9, 6, 6, 'intermediate', '2025-04-11 17:27:18'),
(10, 6, 4, 'advanced', '2025-04-11 17:27:18'),
(11, 6, 3, 'advanced', '2025-04-11 17:27:18'),
(12, 6, 2, 'intermediate', '2025-04-11 17:27:18'),
(13, 6, 1, 'beginner', '2025-04-11 17:27:18'),
(14, 6, 5, 'advanced', '2025-04-11 17:27:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `career_goals`
--
ALTER TABLE `career_goals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chat_history`
--
ALTER TABLE `chat_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `portfolio_items`
--
ALTER TABLE `portfolio_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `portfolio_skills`
--
ALTER TABLE `portfolio_skills`
  ADD PRIMARY KEY (`portfolio_id`,`skill_id`),
  ADD KEY `skill_id` (`skill_id`);

--
-- Indexes for table `progress`
--
ALTER TABLE `progress`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `roadmap_id` (`roadmap_id`);

--
-- Indexes for table `quiz_questions`
--
ALTER TABLE `quiz_questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `skill_id` (`skill_id`);

--
-- Indexes for table `quiz_results`
--
ALTER TABLE `quiz_results`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `skill_id` (`skill_id`);

--
-- Indexes for table `resources`
--
ALTER TABLE `resources`
  ADD PRIMARY KEY (`id`),
  ADD KEY `skill_id` (`skill_id`);

--
-- Indexes for table `roadmap`
--
ALTER TABLE `roadmap`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `resource_id` (`resource_id`);

--
-- Indexes for table `skills`
--
ALTER TABLE `skills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_career_goals`
--
ALTER TABLE `user_career_goals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `career_goal_id` (`career_goal_id`);

--
-- Indexes for table `user_courses`
--
ALTER TABLE `user_courses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `user_skills`
--
ALTER TABLE `user_skills`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `skill_id` (`skill_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `career_goals`
--
ALTER TABLE `career_goals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `chat_history`
--
ALTER TABLE `chat_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `portfolio_items`
--
ALTER TABLE `portfolio_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `progress`
--
ALTER TABLE `progress`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `quiz_questions`
--
ALTER TABLE `quiz_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `quiz_results`
--
ALTER TABLE `quiz_results`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `resources`
--
ALTER TABLE `resources`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `roadmap`
--
ALTER TABLE `roadmap`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13096;

--
-- AUTO_INCREMENT for table `skills`
--
ALTER TABLE `skills`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_career_goals`
--
ALTER TABLE `user_career_goals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user_courses`
--
ALTER TABLE `user_courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_skills`
--
ALTER TABLE `user_skills`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chat_history`
--
ALTER TABLE `chat_history`
  ADD CONSTRAINT `chat_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `portfolio_items`
--
ALTER TABLE `portfolio_items`
  ADD CONSTRAINT `portfolio_items_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `portfolio_skills`
--
ALTER TABLE `portfolio_skills`
  ADD CONSTRAINT `portfolio_skills_ibfk_1` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolio_items` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `portfolio_skills_ibfk_2` FOREIGN KEY (`skill_id`) REFERENCES `skills` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `progress`
--
ALTER TABLE `progress`
  ADD CONSTRAINT `progress_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `progress_ibfk_2` FOREIGN KEY (`roadmap_id`) REFERENCES `roadmap` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `quiz_questions`
--
ALTER TABLE `quiz_questions`
  ADD CONSTRAINT `quiz_questions_ibfk_1` FOREIGN KEY (`skill_id`) REFERENCES `skills` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `quiz_results`
--
ALTER TABLE `quiz_results`
  ADD CONSTRAINT `quiz_results_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `quiz_results_ibfk_2` FOREIGN KEY (`skill_id`) REFERENCES `skills` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `resources`
--
ALTER TABLE `resources`
  ADD CONSTRAINT `resources_ibfk_1` FOREIGN KEY (`skill_id`) REFERENCES `skills` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `roadmap`
--
ALTER TABLE `roadmap`
  ADD CONSTRAINT `roadmap_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `roadmap_ibfk_2` FOREIGN KEY (`resource_id`) REFERENCES `resources` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `user_career_goals`
--
ALTER TABLE `user_career_goals`
  ADD CONSTRAINT `user_career_goals_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_career_goals_ibfk_2` FOREIGN KEY (`career_goal_id`) REFERENCES `career_goals` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_courses`
--
ALTER TABLE `user_courses`
  ADD CONSTRAINT `user_courses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_skills`
--
ALTER TABLE `user_skills`
  ADD CONSTRAINT `user_skills_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_skills_ibfk_2` FOREIGN KEY (`skill_id`) REFERENCES `skills` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
