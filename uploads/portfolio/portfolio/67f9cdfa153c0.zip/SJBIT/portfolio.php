<?php
require_once 'config/database.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get user's skills
$stmt = $pdo->prepare("
    SELECT s.skill_name, us.level, 
        CASE us.level
            WHEN 'advanced' THEN 90
            WHEN 'intermediate' THEN 60
            WHEN 'beginner' THEN 30
        END as skill_percentage
    FROM user_skills us
    JOIN skills s ON us.skill_id = s.id
    WHERE us.user_id = ?
    ORDER BY skill_percentage DESC
");
$stmt->execute([$user_id]);
$skills = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get user's portfolio items
$stmt = $pdo->prepare("
    SELECT pi.*, 
           GROUP_CONCAT(s.skill_name) as skills_used
    FROM portfolio_items pi
    LEFT JOIN portfolio_skills ps ON pi.id = ps.portfolio_id
    LEFT JOIN skills s ON ps.skill_id = s.id
    WHERE pi.user_id = ?
    GROUP BY pi.id
    ORDER BY pi.completion_date DESC
");
$stmt->execute([$user_id]);
$portfolio_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Portfolio - Career Roadmap</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .skill-bar {
            height: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .portfolio-item {
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 30px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        .portfolio-item:hover {
            transform: translateY(-5px);
        }
        .skill-tag {
            background-color: #e9ecef;
            padding: 5px 10px;
            border-radius: 15px;
            margin-right: 5px;
            margin-bottom: 5px;
            display: inline-block;
            font-size: 0.85rem;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container py-5">
        <div class="row">
            <!-- Skills Section -->
            <div class="col-lg-4 mb-4">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Skills Assessment</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($skills)): ?>
                            <p class="text-center text-muted">No skills assessed yet.</p>
                            <div class="text-center">
                                <a href="skill_assessment.php" class="btn btn-primary">Start Skill Assessment</a>
                            </div>
                        <?php else: ?>
                            <?php foreach ($skills as $skill): ?>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <span class="fw-bold"><?php echo htmlspecialchars($skill['skill_name']); ?></span>
                                        <span class="badge bg-<?php 
                                            echo $skill['level'] === 'advanced' ? 'success' : 
                                                ($skill['level'] === 'intermediate' ? 'info' : 'warning'); 
                                        ?>"><?php echo ucfirst($skill['level']); ?></span>
                                    </div>
                                    <div class="progress skill-bar">
                                        <div class="progress-bar bg-<?php 
                                            echo $skill['level'] === 'advanced' ? 'success' : 
                                                ($skill['level'] === 'intermediate' ? 'info' : 'warning'); 
                                        ?>" 
                                            role="progressbar" 
                                            style="width: <?php echo $skill['skill_percentage']; ?>%" 
                                            aria-valuenow="<?php echo $skill['skill_percentage']; ?>" 
                                            aria-valuemin="0" 
                                            aria-valuemax="100">
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            <div class="text-center mt-3">
                                <a href="skill_assessment.php" class="btn btn-primary">Update Skills</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Portfolio Section -->
            <div class="col-lg-8">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>My Portfolio</h2>
                    <a href="add_portfolio.php" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Add Project
                    </a>
                </div>

                <?php if (empty($portfolio_items)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-folder-open fa-4x text-muted mb-3"></i>
                        <h4 class="text-muted">No portfolio items yet</h4>
                        <p class="text-muted">Start adding your projects to showcase your skills!</p>
                        <a href="add_portfolio.php" class="btn btn-primary mt-3">Add Your First Project</a>
                    </div>
                <?php else: ?>
                    <div class="row">
                        <?php foreach ($portfolio_items as $item): ?>
                            <div class="col-md-6 mb-4">
                                <div class="portfolio-item">
                                    <?php if (!empty($item['image_url'])): ?>
                                        <img src="<?php echo htmlspecialchars($item['image_url']); ?>" 
                                             class="card-img-top" 
                                             alt="<?php echo htmlspecialchars($item['title']); ?>">
                                    <?php endif; ?>
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo htmlspecialchars($item['title']); ?></h5>
                                        <p class="card-text"><?php echo htmlspecialchars($item['description']); ?></p>
                                        <?php if (!empty($item['skills_used'])): ?>
                                            <div class="mb-3">
                                                <?php foreach (explode(',', $item['skills_used']) as $skill): ?>
                                                    <span class="skill-tag"><?php echo htmlspecialchars($skill); ?></span>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <small class="text-muted">
                                                <?php echo date('M Y', strtotime($item['completion_date'])); ?>
                                            </small>
                                            <?php if (!empty($item['project_url'])): ?>
                                                <a href="<?php echo htmlspecialchars($item['project_url']); ?>" 
                                                   class="btn btn-sm btn-outline-primary" 
                                                   target="_blank">
                                                    View Project
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Animate progress bars on scroll
        function animateProgressBars() {
            const progressBars = document.querySelectorAll('.progress-bar');
            progressBars.forEach(bar => {
                const rect = bar.getBoundingClientRect();
                if (rect.top < window.innerHeight && rect.bottom > 0) {
                    const width = bar.getAttribute('aria-valuenow') + '%';
                    bar.style.width = '0%';
                    setTimeout(() => {
                        bar.style.width = width;
                    }, 100);
                }
            });
        }

        // Add scroll event listener
        window.addEventListener('scroll', animateProgressBars);
        // Initial animation
        document.addEventListener('DOMContentLoaded', animateProgressBars);
    </script>
</body>
</html> 